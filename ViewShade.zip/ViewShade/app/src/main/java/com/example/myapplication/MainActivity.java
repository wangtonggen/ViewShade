package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import jp.wasabeef.blurry.Blurry;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv1;
    private TextView tv2;
    private TextView tv3;
    private FrameLayout fl_content;
    private AppCompatTextView tv_hint;

    AppCompatButton btn_show;
    AppCompatButton btn_hide;

    private View beforeView;//原来显示的位置
    private View afterView;//点击后的显示位置

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = findViewById(R.id.tv_1);
        tv2 = findViewById(R.id.tv_2);
        tv3 = findViewById(R.id.tv_3);
        fl_content = findViewById(R.id.fl_content);
        tv_hint = findViewById(R.id.tv_hint);

        btn_show = findViewById(R.id.btn_show);
        btn_hide = findViewById(R.id.btn_hide);

//        Blurry.with(this).radius(20).sampling(2).onto(fl_content);

        tv1.setOnClickListener(this);
        tv2.setOnClickListener(this);
        tv3.setOnClickListener(this);
        fl_content.setOnClickListener(this);
        btn_show.setOnClickListener(this);
        btn_hide.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_show:
                if (fl_content.getVisibility() == View.INVISIBLE) {
                    //显示并出现动画
                    fl_content.setVisibility(View.VISIBLE);
                    int random = new Random().nextInt(3);
                    View view;
                    switch (random) {
                        case 0:
                            view = tv1;
                            break;
                        case 1:
                            view = tv2;
                            break;
                        case 2:
                            view = tv3;
                            break;
                        default:
                            view = tv1;
                            break;
                    }
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) fl_content.getLayoutParams();
                    layoutParams.leftMargin = (int) view.getX();
                    layoutParams.topMargin = (int) view.getY();
                    beforeView = view;
                    fl_content.setLayoutParams(layoutParams);
                    showShadeAnimation();
                }
                break;
            case R.id.btn_hide:
                dismissShadeAnimation();
                break;
            case R.id.tv_1:
                afterView = tv1;
                translationShadeAnimation( afterView.getX() - beforeView.getX(), afterView.getY()- beforeView.getY());
                break;
            case R.id.tv_2:
                afterView = tv2;
                translationShadeAnimation(afterView.getX() - beforeView.getX(), afterView.getY() - beforeView.getY());
                break;
            case R.id.tv_3:
                afterView = tv3;
                translationShadeAnimation( afterView.getX() - beforeView.getX(), afterView.getY() - beforeView.getY());
                break;
            case R.id.fl_content:
                Toast.makeText(this, fl_content.getX() + "---" + fl_content.getY(), Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void showShadeAnimation() {
        //动画
        ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(fl_content, "alpha", 0f, 0f, 1f);//
        alphaAnimator.setDuration(300);
        alphaAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        alphaAnimator.start();

        ObjectAnimator scaleYAnimator = ObjectAnimator.ofFloat(fl_content, "scaleY", 0f, 0f, 1f);//
        scaleYAnimator.setDuration(300);
        scaleYAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleYAnimator.start();

        ObjectAnimator scaleXAnimator = ObjectAnimator.ofFloat(fl_content, "scaleX", 0f, 0f, 1f);//
        scaleXAnimator.setDuration(300);
        scaleXAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleXAnimator.start();
    }

    /**
     * 消失动画
     */
    private void dismissShadeAnimation() {
        //动画
        ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(fl_content, "alpha", 1f, 1f, 0f);//
        alphaAnimator.setDuration(300);
        alphaAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        alphaAnimator.start();

        ObjectAnimator scaleYAnimator = ObjectAnimator.ofFloat(fl_content, "scaleY", 1f, 1f, 0f);//
        scaleYAnimator.setDuration(300);
        scaleYAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleYAnimator.start();

        ObjectAnimator scaleXAnimator = ObjectAnimator.ofFloat(fl_content, "scaleX", 1f, 1f, 0f);//
        scaleXAnimator.setDuration(300);
        scaleXAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleXAnimator.start();
    }

    /**
     * 位移动画
     *
     * @param translationX x方向移动的距离
     * @param translationY Y方向移动距离
     */
    private void translationShadeAnimation(float translationX, float translationY) {
        Log.e("tag",translationX+"---"+translationY);
        //动画
        ObjectAnimator translationXAnimator = ObjectAnimator.ofFloat(fl_content, View.TRANSLATION_X,translationX);//
        ObjectAnimator translationYAnimator = ObjectAnimator.ofFloat(fl_content, View.TRANSLATION_Y, translationY);//
        ValueAnimator widthUpdateTranslation = ValueAnimator.ofInt(fl_content.getWidth(),afterView.getWidth());
        widthUpdateTranslation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                Log.e("hahah",animation.getAnimatedValue().toString());
                fl_content.getLayoutParams().width =(Integer)animation.getAnimatedValue();
                fl_content.requestLayout();
            }
        });
        AnimatorSet animationSet = new AnimatorSet();
        animationSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animationSet.playTogether(translationXAnimator, translationYAnimator,widthUpdateTranslation);
        animationSet.setDuration(500);
        animationSet.start();
    }

    private void springAnimation(){
        SpringAnimation springAnimationBikeX = SpringAnimationUtils.createSpringAnimation(view, SpringAnimation.TRANSLATION_X, 220, SpringForce.STIFFNESS_LOW, SpringForce.DAMPING_RATIO_HIGH_BOUNCY);
        SpringAnimation springAnimationBikeY = SpringAnimationUtils.createSpringAnimation(view, SpringAnimation.TRANSLATION_Y, -100, SpringForce.STIFFNESS_LOW, SpringForce.DAMPING_RATIO_HIGH_BOUNCY);
        SpringAnimation springAnimationBikeScaleX = SpringAnimationUtils.createSpringAnimation(view, SpringAnimation.SCALE_X, 0.8f, SpringForce.STIFFNESS_LOW, SpringForce.DAMPING_RATIO_HIGH_BOUNCY);
        SpringAnimation springAnimationBikeScaleY = SpringAnimationUtils.createSpringAnimation(view, SpringAnimation.SCALE_Y, 0.8f, SpringForce.STIFFNESS_LOW, SpringForce.DAMPING_RATIO_HIGH_BOUNCY);
        springAnimationBikeX.start();
        springAnimationBikeY.start();
        springAnimationBikeScaleX.start();
        springAnimationBikeScaleY.start();
    }
}
